#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <Eigen/Dense>
#include <cmath>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <mutex>

// Shared state variables
Eigen::Vector3d x_ = Eigen::Vector3d::Zero();
Eigen::Matrix3d P_ = Eigen::Matrix3d::Identity();
Eigen::Matrix2d Qgamma_;
Eigen::Matrix2d Qwheels_;
Eigen::Matrix2d Qbeta_;
Eigen::Matrix2d jointToCartesian_;
Eigen::Matrix2d cartesianToJoint_;


// Mutex for protecting shared state variables
std::mutex mtx;

double sigma_x, sigma_y, sigma_theta;
double sigma_x_measurement, sigma_y_measurement, sigma_tuning;
double mahalanobis_threshold_;
double initial_x, initial_y, initial_theta;
double wheel_radius_;
double track_gauge_;
double magnet_spacing_x_, magnet_spacing_y_;

void declare_and_get_parameters(rclcpp::Node::SharedPtr node) {
    node->declare_parameter<double>("sigma_x", 4.0);
    node->declare_parameter<double>("sigma_y", 4.0);
    node->declare_parameter<double>("sigma_theta", 0.0698);
    node->declare_parameter<double>("sigma_x_measurement", 5.77);
    node->declare_parameter<double>("sigma_y_measurement", 2.8868);
    node->declare_parameter<double>("sigma_tuning", 0.1);
    node->declare_parameter<double>("mahalanobis_threshold", 2.4477);
    node->declare_parameter<double>("initial_x", 0.0);
    node->declare_parameter<double>("initial_y", 0.0);
    node->declare_parameter<double>("initial_theta", 0.0);
    node->declare_parameter<double>("wheel_radius", 33.0);
    node->declare_parameter<double>("track_gauge", 283);
    node->declare_parameter<double>("magnet_spacing_x", 55);
    node->declare_parameter<double>("magnet_spacing_y", 55);

    node->get_parameter("sigma_x", sigma_x);
    node->get_parameter("sigma_y", sigma_y);
    node->get_parameter("sigma_theta", sigma_theta);
    node->get_parameter("sigma_x_measurement", sigma_x_measurement);
    node->get_parameter("sigma_y_measurement", sigma_y_measurement);
    node->get_parameter("sigma_tuning", sigma_tuning);
    node->get_parameter("mahalanobis_threshold", mahalanobis_threshold_);
    node->get_parameter("initial_x", initial_x);
    node->get_parameter("initial_y", initial_y);
    node->get_parameter("initial_theta", initial_theta);
    node->get_parameter("wheel_radius", wheel_radius_);
    node->get_parameter("track_gauge", track_gauge_);
    node->get_parameter("magnet_spacing_x", magnet_spacing_x_);
    node->get_parameter("magnet_spacing_y", magnet_spacing_y_);

    x_ << initial_x, initial_y, initial_theta;
    P_ = Eigen::Matrix3d::Zero();
    P_(0, 0) = sigma_x * sigma_x;
    P_(1, 1) = sigma_y * sigma_y;
    P_(2, 2) = sigma_theta * sigma_theta;

// Initialize jointToCartesian and cartesianToJoint matrices
    jointToCartesian_ << wheel_radius_ / 2, wheel_radius_ / 2,
                         wheel_radius_ / track_gauge_, -wheel_radius_ / track_gauge_;

    cartesianToJoint_ = jointToCartesian_.inverse();

// Initialize process and measurement noise covariance matrices
    Qwheels_ = sigma_tuning * sigma_tuning * Eigen::Matrix2d::Identity();
    Qbeta_ = jointToCartesian_ * Qwheels_ * jointToCartesian_.transpose();

    Qgamma_ = Eigen::Matrix2d::Zero();
    Qgamma_(0, 0) = sigma_x_measurement * sigma_x_measurement;
    Qgamma_(1, 1) = sigma_y_measurement * sigma_y_measurement;
}

// Joint state callback function
void joint_state_callback(const sensor_msgs::msg::JointState::SharedPtr msg,rclcpp::Node::SharedPtr node) {
    std::lock_guard<std::mutex> lock(mtx); // Lock the mutex

    // Example: Process the joint state message
    // Find the left and right wheel positions
    auto left_it = std::find(msg->name.begin(), msg->name.end(), "wheel_left_joint");
    auto right_it = std::find(msg->name.begin(), msg->name.end(), "wheel_right_joint");

    if (left_it == msg->name.end() || right_it == msg->name.end()) {
        RCLCPP_WARN(node->get_logger(), "Wheel joint names not found");
        return;
    }

    size_t left_index = std::distance(msg->name.begin(), left_it);
    size_t right_index = std::distance(msg->name.begin(), right_it);

    double left_pos = msg->position[left_index];
    double right_pos = msg->position[right_index];

    static double prev_left_pos_ = 0.0;
    static double prev_right_pos_ = 0.0;
    static rclcpp::Time last_time_ = rclcpp::Clock().now();

    rclcpp::Time current_time = rclcpp::Clock().now();
    double dt = (current_time - last_time_).seconds();

    // Calculate wheel displacements
    double delta_left = left_pos - prev_left_pos_;
    double delta_right = right_pos - prev_right_pos_;

    // Update previous positions
    prev_left_pos_ = left_pos;
    prev_right_pos_ = right_pos;

    // Calculate linear and angular displacements
    double dist_left = delta_left * wheel_radius_;
    double dist_right = delta_right * wheel_radius_;

    double delta_d = (dist_left + dist_right) / 2.0;
    double delta_theta = (dist_right - dist_left) / track_gauge_;

    // Update the state estimate
    double theta = x_(2);
    x_(0) += delta_d * cos(theta);
    x_(1) += delta_d * sin(theta);
    x_(2) += delta_theta;

    // Update the state transition Jacobian
    Eigen::Matrix3d A = Eigen::Matrix3d::Identity();
    A(0, 2) = -delta_d * sin(theta);
    A(1, 2) = delta_d * cos(theta);

    Eigen::Matrix<double, 3, 2> B;
    B << cos(theta), 0,
             sin(theta), 0,
              0, 1;
    // Assuming Q_ is globally accessible and initialized
    Eigen::Matrix3d Qalpha_ = Eigen::Matrix3d::Zero();

    P_ = A * P_ * A.transpose() + B * Qbeta_ * B.transpose() + Qalpha_;

    last_time_ = current_time;

    // Mutex is automatically released when lock goes out of scope
}

// Measurement callback function
void measurement_callback(const geometry_msgs::msg::Point::SharedPtr msg, rclcpp::Publisher<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr pose_pub) {
    std::lock_guard<std::mutex> lock(mtx); // Lock the mutex

    // Example: Process the measurement message
    Eigen::Vector2d z_(msg->x, msg->y);

    // Transform from robot frame to world frame
    Eigen::Matrix3d oTm;
    oTm << cos(x_(2)), -sin(x_(2)), x_(0),
           sin(x_(2)),  cos(x_(2)), x_(1),
           0,           0,          1;
    Eigen::Matrix3d mTo = oTm.inverse();

    // Measurement vector in robot frame
    Eigen::Vector3d mMeasMagnet(z_(0), z_(1), 1);

    // Position in world frame
    Eigen::Vector3d oMeasMagnet = oTm * mMeasMagnet;

    // Find the closest actual magnet position
    Eigen::Vector3d oRealMagnet;
    oRealMagnet(0) = std::round(oMeasMagnet(0) / magnet_spacing_x_) * magnet_spacing_x_;
    oRealMagnet(1) = std::round(oMeasMagnet(1) / magnet_spacing_y_) * magnet_spacing_y_;
    oRealMagnet(2) = oMeasMagnet(2); // Assuming z-coordinate remains the same

    // Position in robot frame
    Eigen::Vector3d mRealMagnet = mTo * oRealMagnet;

    // Expected measurement
    Eigen::Vector2d Yhat = mRealMagnet.head<2>();

    // Jacobian matrix C
    Eigen::Matrix<double, 2, 3> C;
    C << -cos(x_(2)), -sin(x_(2)), -sin(x_(2)) * (oRealMagnet(0) - x_(0)) + cos(x_(2)) * (oRealMagnet(1) - x_(1)),
         sin(x_(2)), -cos(x_(2)), -sin(x_(2)) * (oRealMagnet(1) - x_(1)) - cos(x_(2)) * (oRealMagnet(0) - x_(0));

    // Innovation (measurement residual)
    Eigen::Vector2d innov = z_ - Yhat;

    Eigen::Matrix2d S = C * P_ * C.transpose() + Qgamma_;
    double dMaha = sqrt(innov.transpose() * S.inverse() * innov);

    if (dMaha <= mahalanobis_threshold_) {
        // Kalman gain
        Eigen::Matrix<double, 3, 2> K = P_ * C.transpose() * S.inverse();

        // Update state and covariance
        x_ = x_ + K * innov;
        P_ = (Eigen::Matrix3d::Identity() - K * C) * P_;

        // Publish the updated pose
        auto pose_msg = geometry_msgs::msg::PoseWithCovarianceStamped();
        pose_msg.header.stamp = rclcpp::Clock().now();
        pose_msg.header.frame_id = "map";

        pose_msg.pose.pose.position.x = x_(0);
        pose_msg.pose.pose.position.y = x_(1);
        pose_msg.pose.pose.position.z = 0.0;

        tf2::Quaternion q;
        q.setRPY(0, 0, x_(2));
        pose_msg.pose.pose.orientation = tf2::toMsg(q);

        // Flatten the covariance matrix into the pose message
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                pose_msg.pose.covariance[i * 6 + j] = P_(i, j);
            }
        }

        pose_pub->publish(pose_msg);
    }

       // Mutex is automatically released when lock goes out of scope
}

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);

    auto node = std::make_shared<rclcpp::Node>("ekf_localization_node");

    // Declare and get parameters from YAML file
    declare_and_get_parameters(node);
    // Create PUBLISHER for pose
    auto pose_pub = node->create_publisher<geometry_msgs::msg::PoseWithCovarianceStamped>("robot_pose",10);

    // Create subscriptions for joint states and measurements
    auto joint_state_sub = node->create_subscription<sensor_msgs::msg::JointState>(
        "joint_states", 10, [node](const sensor_msgs::msg::JointState::SharedPtr msg) {
            joint_state_callback(msg, node);
        });

    auto measurement_sub = node->create_subscription<geometry_msgs::msg::Point>(
        "measurement_topic", 2, [pose_pub](const geometry_msgs::msg::Point::SharedPtr msg) {
            measurement_callback(msg, pose_pub);
        });
        
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}

