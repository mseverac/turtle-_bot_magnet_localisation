#include <vector>
#include <cstdint>
#include <iostream>
#include <cmath>
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/u_int16.hpp>
#include <geometry_msgs/msg/point.hpp>

using namespace std;
using namespace std::chrono_literals;

class MeasurementNode : public rclcpp::Node
{
public:
    MeasurementNode()
    : Node("measurement_node")
    {
        // Declare parameters
        this->declare_parameter<double>("d0", 0.0);
        this->declare_parameter<double>("z", 0.0);

        // Get parameters
        this->get_parameter("d0", d0_);
        this->get_parameter("z", z_);

        sub_ = this->create_subscription<std_msgs::msg::UInt16>(
            "sensor_data", 10, std::bind(&MeasurementNode::sensorDataCallback, this, std::placeholders::_1));
        pub_ = this->create_publisher<geometry_msgs::msg::Point>("measurement_results_topic", 10);

        timer_ = this->create_wall_timer(
            500ms, std::bind(&MeasurementNode::timerCallback, this));
    }

private:
    void sensorDataCallback(const std_msgs::msg::UInt16::SharedPtr msg)
    {
        rawSensorData = msg->data;
        dataReceived = true;
    }

    void timerCallback()
    {
        if (dataReceived) 
        {
            // Extract measurement
            vector<double> measurements = ExtractMeasurements(rawSensorData, nbReedSensors, magnetDetected);
            cout << "Measurements: ";
            geometry_msgs::msg::Point msg;

            // Output the measurement and publish it
            for (double m : measurements) 
            {
                double transformed_y = 10 * (m - 7.5);   //Offset!
                cout << "(" << d0_ << ", " << transformed_y << ", " << z_ << ") ";
                msg.x = d0_;
                msg.y = transformed_y;
                msg.z = z_;
                pub_->publish(msg);  // Publish the msg into measurement_results_topic
            }
            cout << endl;

            dataReceived = false;  // Restart symbol
        }
    }

    vector<double> ExtractMeasurements(uint16_t rawSensorData, int nbReedSensors, bool magnetDetected)
    {
        vector<bool> bitVector(nbReedSensors + 2, !magnetDetected);
        for (int i = 0; i < nbReedSensors; ++i) 
        {
            bitVector[i + 1] = (rawSensorData & (1 << i)) != 0;  // Extract each number in the binary rawdata
        }
        
        int vectSize = nbReedSensors + 2;
        int i = 1;  // From the first exact measured number.  (in matlab it's 2, in C++ is 1)

        // Find the first detected signal. When it is, quit the looping
        while (i < vectSize && bitVector[i] == !magnetDetected) 
        {
            ++i;
        }
        
        int nbMeasurements = 0;  // Initialize number of measurements (counting)
        vector<double> measurements;  // Initialize the measurement vector, no length, no initial value.
        
        // Start from the first detected signal
        while (i < vectSize) {
            int indBegin = i;
            
            while (i < vectSize && bitVector[i] == magnetDetected) 
            {
                ++i;
            }  // Stop until it's not a detected signal
            
            int indEnd = i - 1;  // One step back to the last detected signal
            
            // Calculate the medium
            double midpoint = (indBegin + indEnd) / 2.0 - 1;  // -1 because we add one more fake sensor at the edge
            
            measurements.push_back(midpoint);  // Put them into the vector. '.push_back' is to add a new element at the end of the queue
            nbMeasurements++;
            
            // Skip the non detected area
            while (i < vectSize && bitVector[i] == !magnetDetected) {
                ++i;
            }
        }
        cout << "Number of measurements:" << nbMeasurements << endl;
        return measurements;
    }

    rclcpp::Subscription<std_msgs::msg::UInt16>::SharedPtr sub_;
    rclcpp::Publisher<geometry_msgs::msg::Point>::SharedPtr pub_;
    rclcpp::TimerBase::SharedPtr timer_;
    uint16_t rawSensorData;
    bool dataReceived = false;
    int nbReedSensors = 16;
    bool magnetDetected = false;
    double d0_;
    double z_;
};

int main(int argc, char **argv) 
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<MeasurementNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}


